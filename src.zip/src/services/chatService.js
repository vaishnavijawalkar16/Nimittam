import { getModel } from '../storage/modelStorage';

export async function getBotReply(text) {
  if (!getModel()) return '';
  return `You said: ${text}`;
}
